package fase2;

import modelo.*;
import vista.*;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Fase2 {
    
    //private static ResultSet rs;
    private static Vista1 v1;
    private static Perfil p;
    private static int c;
    private static ArrayList<String> nombres;
    private static Trabajador t;
    private static ArrayList<Integer> centros;

    public static void main(String[] args) {
        
        GenericaBD.abrirConexion();
        CentroBD.solicitarCentros();
        v1 = new Vista1(centros);
        v1.setVisible(true);
    }

    public static void crearPerfil(int idCentro) {
        c = idCentro;
        p = new Perfil();
        p.setVisible(true);
    }
    
    /*
    public static ArrayList<Integer> convertir(ResultSet rs) {
        try {
            ArrayList<Integer> centros = new ArrayList();
            nombres = new ArrayList();
            while(rs.next()){
                centros.add(rs.getInt(1));
                nombres.add(rs.getString(2));
            }
            return centros;
        } catch (SQLException ex) {
            System.out.println("error " + ex.getMessage());
            return null;
        }
    }
    */
    
    public static String nombreCentro(Integer centro){
        return nombres.get(centro);
    }

    public static boolean buscarTrabajador(String dni) {
        t = TrabajadorBD.getTrabajador(dni);
        if(t == null){
            return false;
        }else{
            return true;
        }
    }

    public static void borrarTrabajador() {
        TrabajadorBD.borrar(t);
    }
    
    public static String getNombre(){
        return t.getNombre();
    }
    
    public static String getApe1(){
        return t.getApellido1();
    }
    
    public static String getApe2(){
        return t.getApellido2();
    }
    
    public static String getCalle(){
        return t.getCalle();
    }
    
    public static String getPortal(){
        return t.getPortal();
    }
    
    public static String getPiso(){
        return String.valueOf(t.getPiso());
    }
    
    public static String getMano(){
        return t.getMano();
    }
    
    public static String getPersonal(){
        return t.getTelPersonal();
    }
    
    public static String getEmpresa(){
        return t.getTelEmpresa();
    }
    
    public static Calendar getFechaNac(){
        if (t.getFechaNac()!=null)
        {
            Calendar ca = Calendar.getInstance();
            ca.setTime(t.getFechaNac());
            return ca;
        }
        return null;
    }
    
    public static String getSalario(){
        return String.valueOf(t.getSalario());
    }
    
    public static Class getClase(){
        return t.getClass();
    }
    
    public static Class getClaseLogistica(){
        return Logistica.class.getClass();
    }

    public static void setNombre(String nombre) {
        t.setNombre(nombre);
    }

    public static void setDni(String dni) {
        t.setDni(dni);
    }

    public static void setApellidos(String ape) {
        int c = ape.length();
        if(ape.contains(" ")){
            c = ape.indexOf(" ");
        }
        t.setApellido1(ape.substring(0, c));
        t.setApellido2(ape.substring(c));
    }

    public static void setCalle(String calle) {
        t.setCalle(calle);
    }

    public static void setPortal(String portal) {
        t.setPortal(portal);
    }

    public static void setPiso(String piso) {
        t.setPiso(Integer.parseInt(piso));
    }

    public static void setMano(String mano) {
        t.setMano(mano);
    }

    public static void setPersonal(String per) {
        t.setTelPersonal(per);
    }

    public static void setEmpresa(String emp) {
        t.setTelEmpresa(emp);
    }

    public static void setSalario(String salario) {
        t.setSalario(Float.parseFloat(salario));
    }

    public static void setFecha(Calendar fecha) {
        t.setFechaNac(fecha.getTime());
    }

    public static void insertar() {
        TrabajadorBD.insertar(t);
        javax.swing.JOptionPane.showMessageDialog(p, "Usuario insertado");
        System.exit(0);
    }

    public static void iniAdmin() {
        t = new Administracion();
    }

    public static void iniLog() {
        t = new Logistica();
    }

    public static void modificar() {
        TrabajadorBD.modificar(t);
        javax.swing.JOptionPane.showMessageDialog(p, "Usuario modificado");
        System.exit(0);
    }

    public static void guardarCentros(ArrayList<Integer> pCentros) {
        centros = pCentros;
    }

    public static void guardarNombres(ArrayList<String> pNombres) {
        nombres = pNombres;
    }
}
