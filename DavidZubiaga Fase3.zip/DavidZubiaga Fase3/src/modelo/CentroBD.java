/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import fase2.*;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author 1gprog12
 */
public class CentroBD {
    
    /*
    public static void solicitarCentros() {
        try {
            Connection con = GenericaBD.getCon();
            Statement sentencia = con.createStatement();
            ResultSet rs = sentencia.executeQuery("SELECT * FROM PROGCENTROS");
            convertir(rs);
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
    }
    */
    
    public static void solicitarCentros(){
        try {
            CallableStatement cst = GenericaBD.getCon().prepareCall("{call PACKFASE3.VER_CENTROS(?)}");
            cst.registerOutParameter(1, OracleTypes.CURSOR);
            cst.execute();
            ResultSet rs = (ResultSet) cst.getObject(1);
            if(!rs.next()){
                throw new Exception();
            }else{
                convertir(rs);
            } 
        }catch (Exception ex) {
            System.out.println("Error al acceder a los datos de los centros" + ex.getMessage());
        }
    }
    
    public static void convertir(ResultSet rs) {
        try {
            ArrayList<Integer> centros = new ArrayList();
            ArrayList<String> nombres = new ArrayList();
            nombres = new ArrayList();
            do{
                centros.add(rs.getInt(1));
                nombres.add(rs.getString(2));
            }while(rs.next());
            Fase2.guardarCentros(centros);
            Fase2.guardarNombres(nombres);
        } catch (SQLException ex) {
            System.out.println("error " + ex.getMessage());
        }
    }
    
    public static void insertar(Centro c) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("INSERT INTO PROGCENTROS VALUES (?,?)");
            ps.setInt(1, c.getId());
            ps.setString(2, c.getNombre());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error al insertar los datos del nuevo centro");
        }
    }

    public static void modificar(Centro c) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("UPDATE PROGCENTROS SET ID = ?, NOMBRE = ?");
            ps.setInt(1, c.getId());
            ps.setString(2, c.getNombre());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error al modificar los datos del centro");
        }
    }

    public static void borrar(Centro c) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("DELETE FROM PROGCENTROS WHERE ID = ?");
            ps.setInt(1, c.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error al borrar el centro");
        }
    }
    
}
