package proyecto;

import excepciones.*;
import java.io.IOException;
import modelo.*;
import vista.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Proyecto {
    /**
     * Trabajador t es el equivalente al usuario que está iniciado sesión
     * Trabajador trab sería cualquier trabajador que se vaya a buscar en la base de datos
     * 
     * El listaViajesA es para los abiertos y el listaViajes es para los demás
     */
    private static Perfil p;
    private static Centro c;
    private static Trabajador t;
    private static Trabajador trab;
    private static ArrayList<Parte> listaPartes;
    private static Principal pr;
    private static VentanaCentros vc;
    private static ArrayList<Vehiculo> listaVehiculos ;
    private static VistaParte vistaParte;
    private static VistaAfterParte vAp;
    private static Viaje v;
    private static Parte ap;
    private static VisualizarParte vp;
    private static ArrayList<Viaje> listaViajes;
    private static ArrayList<Viaje> listaViajesA;

    public static void main(String[] args) {
        
        try {
            GenericaBD.abrirConexion();
            pr = new Principal();
            pr.setVisible(true);
            Login dialog = new Login (pr,true);
            dialog.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(Proyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void generarInforme(String pMes){
        ParserProyecto pp = new ParserProyecto(pMes);
    }

    public static ArrayList<Viaje> getListaViajes() {
        return listaViajes;
    }
    
    public static ArrayList<Vehiculo> getListaVehiculos() {
        return listaVehiculos;
    }
    
    public static Parte getAp() {
        return ap;
    }

    public static ArrayList<Parte> getListaPartes() {
        return listaPartes;
    }

    public static void ventanaPartes ()
    {
        vistaParte = new VistaParte();
        vistaParte.setVisible(true);
    }
    
    public static void seleccionarVehiculos() {
        listaVehiculos = new ArrayList();
        listaVehiculos = VehiculosBD.seleccionarVehiculos();
    }
    
    public static void preguntaFinal() {
        vistaParte.preguntaFinal();
    }
    
    public static void ventanaAfterParteAbrir(){        
        vAp = new VistaAfterParte();
        vAp.setVisible(true);
    }    
    public static void ventanaAfterParteCerrar(){
        vAp.dispose();
        vistaParte.dispose();
    }
    /**
     * La ventana de VistaAfterParte , pasa los siguientes datos y se agregan a la bbdd en partes
     * 
     * @param fecha
     * @param kmInicial
     * @param kmFinal
     * @param gasolina
     * @param peaje
     * @param dietas
     * @param otros
     * @param incidencia
     * @param estado 
     */
    
    public static void rellenarParte(java.sql.Date fecha, int kmInicial, int kmFinal, int gasolina, int peaje, int dietas, int otros, String incidencia, String estado)
    {
        
        try {
            ap = new Parte(fecha,kmInicial,kmFinal,gasolina,peaje,dietas,otros,incidencia,estado,t);
            ParteBD.agregarParte(ap);
            
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    /**
     * Desde VistaParte pasa los datos que se va a utilizar para insertar en la bbdd
     * @param albaran
     * @param horaSalida
     * @param horaLlegada
     * @param matricula 
     */
    
    public static void rellenarViaje(int albaran, String horaSalida, String horaLlegada, String matricula)
    {
        try {
            v = new Viaje(albaran,horaSalida,horaLlegada,matricula,ap.getIdParte());
            ViajeBD.agregarAlbaran(v);
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error "+ e.getMessage());
        }  
    }

    /**
     * Es igual que el rellenarViajes , pero en este caso es para modificarlos
     * @param albaran
     * @param horaSalida
     * @param horaLlegada
     * @param matricula 
     */
    
    public static void modificarViaje(int albaran, String horaSalida, String horaLlegada, String matricula)
    {
        try {
            v = new Viaje(albaran,horaSalida,horaLlegada,matricula,ap.getIdParte());
            ViajeBD.agregarAlbaran(v);
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error "+ e.getMessage());
        }  
    }
    
    public static void setParteId(int pId) {
        ap.setIdParte(pId);
    }

    public static void crearPerfil() {
        p = new Perfil();
        p.setVisible(true);
    }
    /**
     * Busca el trabajador según el id
     * @param dni
     * @return 
     */
    public static boolean buscarTrabajador(String dni) {
        trab = TrabajadorBD.getTrabajador(dni);
        if(trab == null){
            return false;
        }else{
            return true;
        }
    }
    
    public static Trabajador getTrab(){
        return trab;
    }
    
    public static Trabajador getT(){
        return t;
    }
    
    public static String getNombre(){
        return t.getNombre();
    }
    
    public static String getDni(){
        return t.getDni();
    }
    
    public static String getApe1(){
        return t.getApellido1();
    }
    
    public static String getApe2(){
        return t.getApellido2();
    }
    
    public static String getCalle(){
        return t.getCalle();
    }
    
    public static String getPortal(){
        return t.getPortal();
    }
    
    public static String getPiso(){
        return String.valueOf(t.getPiso());
    }
    
    public static String getMano(){
        return t.getMano();
    }
    
    public static String getPersonal(){
        return t.getTelPersonal();
    }
    
    public static String getEmpresa(){
        return t.getTelEmpresa();
    }
    /**
     * Cambia de Date a Calendar
     * @return 
     */
    public static Calendar getFechaNac(){
        if (t.getFechaNac()!=null)
        {
            Calendar ca = Calendar.getInstance();
            ca.setTime(t.getFechaNac());
            return ca;
        }
        return null;
    }
    
    public static String getSalario(){
        return String.valueOf(t.getSalario());
    }
    
    public static String getCen(){
        return String.valueOf(t.getCentro());
    }
    
    public static Class getClase(){
        return t.getClass();
    }
    
    public static Class getClaseLogistica(){
        return Logistica.class;
    }

    public static void setNombre(String nombre) {
        t.setNombre(nombre);
    }

    public static void setDni(String dni) {
        t.setDni(dni);
    }
/**
 * Coge un String de Apellidos y lo divide en 2
 * @param ape 
 */
    public static void setApellidos(String ape) {
        int c = ape.length();
        if(ape.contains(" ")){
            c = ape.indexOf(" ");
        }
        t.setApellido1(ape.substring(0, c));
        t.setApellido2(ape.substring(c+1));
    }

    public static void setCalle(String calle) {
        t.setCalle(calle);
    }

    public static void setPortal(String portal) {
        t.setPortal(portal);
    }

    public static void setPiso(String piso) {
        t.setPiso(Integer.parseInt(piso));
    }

    public static void setMano(String mano) {
        t.setMano(mano);
    }

    public static void setPersonal(String per) {
        t.setTelPersonal(per);
    }

    public static void setEmpresa(String emp) {
        t.setTelEmpresa(emp);
    }

    public static void setSalario(String salario) {
        t.setSalario(Float.parseFloat(salario));
    }

    public static void setFecha(Calendar fecha) {
        t.setFechaNac(fecha.getTime());
    }

    /**
     * Según si el usuario se inserta o no te devuelve una cosa u otra
     */
    public static void insertar() {
        if(TrabajadorBD.insertar(trab)){
            javax.swing.JOptionPane.showMessageDialog(p, "Usuario insertado");
        }else{
            javax.swing.JOptionPane.showMessageDialog(p, "Error al insertar el usuario");
        }
    }
    /**
     * Según si el usuario se borra o no te devuelve una cosa u otra
     */
    public static void borrarTrabajador() {
        if(TrabajadorBD.borrar(trab)){
            javax.swing.JOptionPane.showMessageDialog(p, "Usuario borrado");
        }else{
            javax.swing.JOptionPane.showMessageDialog(p, "Error al borrar el usuario");
        }
    }
        /**
     * Según si el usuario se modifica o no te devuelve una cosa u otra
     */
    public static void modificar() {
        if(TrabajadorBD.modificar(trab)){
            javax.swing.JOptionPane.showMessageDialog(p, "Usuario modificado");
        }else{
            javax.swing.JOptionPane.showMessageDialog(p, "Error al modificar el usuario");
        }
    }
    /**
     * Inicializar el de Administración o el de logística
     */
    public static void iniAdmin() {
        trab = new Administracion();
    }

    public static void iniLog() {
        trab = new Logistica();
    }
/**
 * En el TexTfield de constraseñas el valor devuelto es un char[] , asi que aquí juntamos lo que nos pasa y lo cambiamos a un String que despues se busca en la base de datos
 * y se comprueba si es valido o no
 * @param text
 * @param password
 * @return 
 */
    public static boolean comprobarUsuario(String text, char[] password) {
        int x;
        String contraseña="";
        for(x=0;x<password.length;x++)
        {
            contraseña += password[x];
        }
        boolean comprobado = TrabajadorBD.login(text, contraseña);
        if(comprobado){
            t = TrabajadorBD.getTrabajador(text);
            return true;
        }else{
            return false;
        }
    }

    public static void tipoTrabajador(boolean b) {
        pr.cerrarPestanas(b);
    }

    public static void mostrarPerfil(){
        p = new Perfil();
        p.setVisible(true);
        p.visualizar();
    }
    
    public static void mostrarTrab(){
        p = new Perfil();
        p.setVisible(true);
        p.modificarTrab();
    }
    
    public static void cerrarConexion(){
        GenericaBD.cerrarConexion();
    }
    
    public static String getNombreT(){
        return trab.getNombre();
    }
    
    public static String getDniT(){
        return trab.getDni();
    }
    
    public static String getApe1T(){
        return trab.getApellido1();
    }
    
    public static String getApe2T(){
        return trab.getApellido2();
    }
    
    public static String getCalleT(){
        return trab.getCalle();
    }
    
    public static String getPortalT(){
        return trab.getPortal();
    }
    
    public static String getPisoT(){
        return String.valueOf(trab.getPiso());
    }
    
    public static String getManoT(){
        return trab.getMano();
    }
    
    public static Class getClaseT(){
        return trab.getClass();
    }
    
    public static String getPersonalT(){
        return trab.getTelPersonal();
    }
    
    public static String getEmpresaT(){
        return trab.getTelEmpresa();
    }
    
    public static Calendar getFechaNacT(){
        if (trab.getFechaNac()!=null)
        {
            Calendar ca = Calendar.getInstance();
            ca.setTime(trab.getFechaNac());
            return ca;
        }
        return null;
    }
    
    public static String getSalarioT(){
        return String.valueOf(trab.getSalario());
    }
    
    public static void setDniT(String dni) {
        trab.setDni(dni);
    }

    public static void setNombreT(String nombre) {
        trab.setNombre(nombre);
    }

    public static void setApellidosT(String ape) {
        int c = ape.length();
        if(ape.contains(" ")){
            c = ape.indexOf(" ");
        }
        trab.setApellido1(ape.substring(0, c));
        trab.setApellido2(ape.substring(c+1));
    }

    public static void setCalleT(String calle) {
        trab.setCalle(calle);
    }

    public static void setPortalT(String portal) {
        trab.setPortal(portal);
    }

    public static void setPisoT(String piso) {
        trab.setPiso(Integer.parseInt(piso));
    }

    public static void setManoT(String mano) {
        trab.setMano(mano);
    }

    public static void setPersonalT(String per) {
        trab.setTelPersonal(per);
    }

    public static void setEmpresaT(String emp) {
        trab.setTelEmpresa(emp);
    }

    public static void setSalarioT(String salario) {
        trab.setSalario(Float.parseFloat(salario));
    }

    public static void setFechaT(Calendar fecha) {
        trab.setFechaNac(fecha.getTime());
    }
/**
 * Se selecciona el centro y se devuelve true o false
 * @param id
 * @return 
 */
    public static boolean getCentro(int id) {
        c = null;
        CentroBD.solicitarCentro(id);
        if(c == null){
            return false;
        }else{
            return true;
        }
    }
    
    public static void setCentroT(String pCentro){
        trab.setCentro(Integer.parseInt(pCentro));
    }
    
    public static String getCentroT(){
        return String.valueOf(trab.getCentro());
    }

    public static void setCentro(Centro pC) {
        c = pC;
    }

    public static void mostrarCentro() {
        crearCentro();
        vc.visualizar();
    }
    
    public static int getId(){
        return c.getId();
    }
    
    public static int getNumero(){
        return c.getNumero();
    }
    
    public static int getCp(){
        return c.getCp();
    }
    
    public static String getNombreC(){
        return c.getNombre();
    }
    
    public static String getCalleC(){
        return c.getCalle();
    }
    
    public static String getCiudad(){
        return c.getCiudad();
    }
    
    public static String getProvincia(){
        return c.getProvincia();
    }
    
    public static String getTelefono(){
        return c.getTelefono();
    }
    
    public static ArrayList getListado(){
        return c.getListado();
    }

    public static void crearCentro() {
        vc = new VentanaCentros();
        vc.setVisible(true);
    }
    
    public static void setNumero(Integer pNum){
        c.setNumero(pNum);
    }
    
    public static void setCp(Integer pCp){
        c.setCp(pCp);
    }
    
    public static void setNombreC(String pNombre){
        c.setNombre(pNombre);
    }
    
    public static void setCalleC(String pCalle){
        c.setCalle(pCalle);
    }
    
    public static void setCiudad(String pCiudad){
        c.setCiudad(pCiudad);
    }
    
    public static void setProvincia(String pProvincia){
        c.setProvincia(pProvincia);
    }
    
    public static void setTelefono(String pTelefono){
        c.setTelefono(pTelefono);
    }

    public static void iniCentro() {
        c = new Centro();
    }

    public static void modificarC() {
        crearCentro();
        vc.modificar();
    }

    public static void insertarCentro() {
        if(CentroBD.insertar(c)){
            javax.swing.JOptionPane.showMessageDialog(vc, "Centro insertado");
        }else{
            javax.swing.JOptionPane.showMessageDialog(vc, "Error al insertar el centro");
        }
    }
    
    public static void modificarCentro() {
        if(CentroBD.modificar(c)){
            javax.swing.JOptionPane.showMessageDialog(vc, "Centro modificado");
        }else{
            javax.swing.JOptionPane.showMessageDialog(vc, "Error al modificar el centro");
        }
    }

    public static void eliminarC() {
        if(CentroBD.borrar(c)){
            javax.swing.JOptionPane.showMessageDialog(vc, "Centro borrado");
        }else{
            javax.swing.JOptionPane.showMessageDialog(vc, "Error al borrar el centro");
        }
    }

    public static void modificarPartesAbiertos(){
        vp = new VisualizarParte();
        vp.setVisible(true);
    }
    
    public static void visualizarPartes(){
        vp = new VisualizarParte();
        vp.setVisible(true);
        vp.visualizar();
    }
    
    public static void encontrarAbiertos(java.sql.Date d){
        listaPartes = ParteBD.seleccionarPartes(d);
    }
    
    public static void encontrarAbiertosTrabajador(java.sql.Date date) {
        listaPartes = ParteBD.seleccionarPartesTrabajador(date);
    }

    public static void partesNoValidados(java.sql.Date date) {
        listaPartes = ParteBD.seleccionarPartesNoValidados(date);
        
    }

    /**
     * Desde la VistaAfterParte le pasa los datos y los inserta en la Base de datos en la tabla de partes
     * @param kmInicial
     * @param kmFinal
     * @param gasolina
     * @param peaje
     * @param dietas
     * @param otros
     * @param incidencia
     * @param estado 
     */
    public static void actualizarViajes(int kmInicial, int kmFinal, int gasolina, int peaje, int dietas, int otros, String incidencia, String estado) {
        try {
            ap.setKmInicial(kmInicial);
            ap.setKmFinal(kmFinal);
            ap.setDietas(dietas);
            ap.setEstado(estado);
            ap.setGasolina(gasolina);
            ap.setIncidencia(incidencia);
            ap.setOtros(otros);
            ap.setPeaje(peaje);
            if(ParteBD.actualizarParte(ap)){
                javax.swing.JOptionPane.showMessageDialog(vc, "Parte actualizado");
            }else{
                javax.swing.JOptionPane.showMessageDialog(vc, "Error al actualizar el parte");
            }
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al modificar los datos");
        }
   
    }

    public static void seleccionarPartesViaje(int id){
        //listaViajes = new ArrayList();
        
        for (int i = 0; i < listaPartes.size(); i++) {
            if(listaPartes.get(i).getIdParte() == id){
                ap = listaPartes.get(i);
            }
        }
        listaViajes = ViajeBD.agregarViaje(id);
    }

    public static void vistaParteModificar() {
        vistaParte = new VistaParte();
        vistaParte.setVisible(true);
        vistaParte.modificar();
        vistaParte.rellenarDatos(listaViajes);
    }
    

    public static void validar() {
        vp = new VisualizarParte();
        vp.setVisible(true);
        vp.validar();
    }
    /**
     * La ventana de VistaParte le pasa los datos para actualizar la bbdd
     * @param Albaran
     * @param horaSalida
     * @param horaLlegada
     * @param matricula 
     */
    public static void actualizarViaje(int Albaran,String horaSalida,String horaLlegada,String matricula) {
        ViajeBD.actualizarViaje(Albaran, horaSalida, horaLlegada, matricula, ap.getIdParte());
    }

    /**
     * Este metodo tiene un parametro que sirve para mostrar los trabajadores
     * @param pId
     * @return 
     */
    public static String buscarTrabajadoresCentro(int pId) {
        ArrayList<Trabajador> lista = TrabajadorBD.getTrabajadoresCentro(pId);
        String texto = "";
        if(lista != null){
            for (int i = 0; i < lista.size(); i++) {
                texto += lista.get(i).getNombre() + " " + lista.get(i).getApellido1() + " " + lista.get(i).getApellido2() + " con DNI: " + lista.get(i).getDni() + "\n";
            }
        }
        return texto;
    }

    /**
     * selecciona todo los partes del trabajador que se desea y que los partes estén abiertos
     */
    public static void modificarPartesAbiertosT() {
        ap = new Parte();
        ap = ParteBD.seleccionarParteTrabajador();
        if(ap != null){
            vistaParte = new VistaParte();
        vistaParte.setVisible(true);
        listaViajesA = new ArrayList();
        listaViajesA = ViajeBD.agregarViaje(ap.getIdParte());
        vistaParte.rellenarDatos(listaViajesA);
        }
    }

    /**
     * Abrir la ventana de vistaParte y rellenar los datos
     */
    public static void vistaParteValidar() {
        vistaParte = new VistaParte();
        vistaParte.setVisible(true);
        vistaParte.Validar();
        vistaParte.rellenarDatos(listaViajes);
    }
    /**
     * Hace un update en la base de datos para actualizar los partes a validado que sí 
     */
    public static void validarParte() {
        ParteBD.validar(ap);
    }
    /**
     * Abrir la ventana de vistaParte y rellenar los datos si es necesario
     */ 
    public static void vistaParteVisualizar() {
        vistaParte = new VistaParte();
        vistaParte.setVisible(true);
        vistaParte.Visualizar();
        vistaParte.rellenarDatos(listaViajes);
    }

    /**
     * Función para actualizar el parte, se consiguen los datos de la ventana de VisualizarParte
     * @param parseInt
     * @param fechaActual
     * @param parseInt0
     * @param parseInt1
     * @param parseInt2
     * @param parseInt3
     * @param parseInt4
     * @param parseInt5
     * @param text
     * @param cerrado 
     */
    
    public static void actualizarViajesN(int parseInt, Date fechaActual, int parseInt0, int parseInt1, int parseInt2, int parseInt3, int parseInt4, int parseInt5, String text, String cerrado) {
        try {
            ap = new Parte(parseInt, (java.sql.Date) fechaActual, parseInt0, parseInt1, parseInt2, parseInt3, parseInt4, parseInt5, text, cerrado, trab);
            if(ParteBD.actualizarParte(ap)){
                javax.swing.JOptionPane.showMessageDialog(vc, "Parte actualizado");
            }else{
                javax.swing.JOptionPane.showMessageDialog(vc, "Error al actualizar el parte");
            }
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al modificar los datos");
        }
    }

    /**
     * Función para eliminar parte y viaje
     * @param idParte 
     */
    public static void eliminarParte(int idParte) {
        ViajeBD.eliminarViajes(idParte);
        ParteBD.eliminarParte(idParte);
    }
    /**
     * Si un parte está abierto e intenta crear otro , esta función comprueba si ese trabajador tiene alguno abierto y si lo tiene , avisa de que hay un parte abierto y que debe cerrarlo
     */
    public static void parteAbiertoSinCerrar()
    {
        try {
            if(ParteBD.seleccionarParteTrabajadorAbierto(t))
            {
                JOptionPane.showMessageDialog(null, "Hay un parte abierto por este trabajador , cierralo antes de crear otro");
            }else
            {
                ventanaPartes();
            }
        } catch (Exception e) {
        }
    }
}
