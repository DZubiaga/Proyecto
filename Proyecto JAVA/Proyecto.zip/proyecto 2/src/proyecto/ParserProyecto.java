package proyecto;

import modelo.*;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Calendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class ParserProyecto {

    private ArrayList<Parte> partes;
    private Document dom;
    private String fecha;
    
    public ParserProyecto() {
        
    }

    public ParserProyecto(String fecha) {
        this.fecha = fecha;
        marcha();
    }
    
    public void marcha(){
        sacarParte();
        crearDocumento();
        elements();
        printToFile();
        ParserBD.InsertarInformesXML(getStringFromDocument(dom));
        javax.swing.JOptionPane.showMessageDialog(null, "Informe generado correctamente");
    }

    public void sacarParte(){
        partes = ParteBD.seleccionarPartesMes(fecha);
    }    

    public void crearDocumento(){
        DocumentBuilderFactory factoria = DocumentBuilderFactory.newInstance();
        try{
            DocumentBuilder constructor = factoria.newDocumentBuilder();
            dom = constructor.parse("./Parte.xml");
        }
        catch(Exception e){} 
    }       
   
    public void elements(){
        Element elemento_principal = dom.getDocumentElement();
        elemento_principal.setAttribute("Mes", fecha);
        String[] titulos = {"ID","Kminicio","Kmfinal","gasolina","peaje","dietas","otros","incidencias","trabajador"};
        int n = 0;
        while(n < partes.size()){
            Element parte = dom.createElement("Parte");
            parte.appendChild(subElements(titulos[0], partes.get(n).getIdParte() + ""));
            parte.appendChild(subElements(titulos[1], partes.get(n).getKmInicial() + ""));
            parte.appendChild(subElements(titulos[2], partes.get(n).getKmFinal() + ""));
            parte.appendChild(subElements(titulos[3], partes.get(n).getGasolina() + ""));
            parte.appendChild(subElements(titulos[4], partes.get(n).getPeaje() + ""));
            parte.appendChild(subElements(titulos[5], partes.get(n).getDietas() + ""));
            parte.appendChild(subElements(titulos[6], partes.get(n).getOtros() + ""));
            parte.appendChild(subElements(titulos[7], partes.get(n).getIncidencia() + ""));
            parte.appendChild(subElements(titulos[8], partes.get(n).getT().getDni() + ""));
            elemento_principal.appendChild(parte);
            n++;
        }
    } 
    
    public static Class getClaseLogistica(){
        return Logistica.class;
    }

    public Element subElements(String titulo, String texto){
        Element elemento = dom.createElement(titulo);
        Text nodo_texto = dom.createTextNode(texto);
        elemento.appendChild(nodo_texto);
        return elemento;
    }
  
    private void printToFile() {
        try {
            Calendar c = Calendar.getInstance();
            int m = c.get(Calendar.MONTH)+1;
            int y = c.get(Calendar.YEAR);
            OutputFormat format = new OutputFormat(dom);
            format.setIndenting(true);
            XMLSerializer serializer = new XMLSerializer(new FileOutputStream(new File("Informe " + m + "-" + y + " XML.xml")), format);
            serializer.serialize(dom);
        } catch (IOException ie) {
            ie.printStackTrace();
        }
    }    

    private static String getStringFromDocument(Document document){
        try{
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(document), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        }
        catch(Exception e){
            return "";
        }
    }
}
