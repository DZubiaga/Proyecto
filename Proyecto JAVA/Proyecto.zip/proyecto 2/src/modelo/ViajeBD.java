package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import proyecto.Proyecto;

public class ViajeBD {
    
    private static Viaje vi;
    private static ArrayList<Viaje> listado;
    
    public static boolean agregarAlbaran(Viaje v){
        try {
            try {
                PreparedStatement ps = GenericaBD.getCon().prepareStatement("delete from VIAJES where parte = ? and albaran = ?");
                ps.setInt(1, v.getParte());
                ps.setInt(2, v.getAlbaran());
                ps.executeUpdate();
            } catch (Exception e) {
            }finally{
                PreparedStatement ps = GenericaBD.getCon().prepareStatement("INSERT INTO VIAJES VALUES (?,?,?,?,?)");
                ps.setInt(1, v.getAlbaran());
                ps.setString(2, v.getHoraSalida());
                ps.setString(3, v.getHoraLlegada());
                ps.setString(4, v.getMatricula());
                ps.setInt(5, v.getParte());
                ps.executeUpdate();
                return true;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al Insertar el Viaje" + e.getMessage());
            return false;
        }
    }
    
    public static ArrayList<Viaje> agregarViaje(int id){
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("Select * from viajes where PARTE = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            listado = new ArrayList();
            while(rs.next()){
                vi = new Viaje(rs.getInt("ALBARAN"),rs.getString("HORASALIDA"),rs.getString("HORALLEGADA"),rs.getString("MATRICULA"));
                listado.add(vi);
            }
            return listado;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error al seleccionar los viajes");
            return null;
        }
    }
    
    public static boolean actualizarViaje(int albaran,String horaSalida,String horaLlegada,String matricula, int parte){
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("UPDATE VIAJES SET HORASALIDA=?,HORALLEGADA=?,MATRICULA=? WHERE ALBARAN=? and parte = ?");
            ps.setString(1, horaSalida);
            ps.setString(2, horaLlegada);
            ps.setString(3,matricula);
            ps.setInt(4, albaran);
            ps.setInt(5, parte);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            return false;
        }
    }
    
    public static boolean eliminarViajes(int idParte){
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("delete from viajes where parte = ?");
            ps.setInt(1, idParte);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el viaje" + e.getMessage());
            return false;
        }
    }
}
