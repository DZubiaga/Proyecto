/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 * 
 * @author 1gprog12
 */
public class GenericaBD {
    
    private static Connection con;
    /**
     * Se abre la base de datos
     * @return 
     */
    public static boolean abrirConexion(){
        
        con = null;
        try{
            DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
            con = DriverManager.getConnection("jdbc:oracle:thin:@SrvOracle:1521:orcl","daw05","daw05");
            return true;
        }catch(Exception e){
            System.out.println("Problemas" + e);
            return false;
        }
    }
    /**
     * Se cierra la base de datos
     * @return 
     */
    
    public static boolean cerrarConexion(){
        try {
            con.close();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problemas" + ex);
            return false;
        }
    }
    /**
     * Te devuleve un objeto de tipo conexion
     * @return 
     */
    public static Connection getCon(){
        return con;
    }
}
