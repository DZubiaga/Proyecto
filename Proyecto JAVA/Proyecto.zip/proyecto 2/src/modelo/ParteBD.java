
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Date;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import proyecto.Proyecto;

public class ParteBD {

    private static Trabajador t;
    private static ArrayList<Parte> listado;
  
    /**
     * Inserta un parte en la base de datos
     * @param ap 
     */
    public static void agregarParte(Parte ap)
    {
        try {
             
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("Insert into partes (FECHA,KMINICIO,KMFINAL,GASOLINA,PEAJE,DIETAS,OTROS,INCIDENCIA,ESTADO,TRABAJADOR, VALIDADO) values(?,?,?,?,?,?,?,?,?,?, 'No')",new String[]{"IDPARTE"});
             
            ps.setDate(1, ap.getFecha());
            ps.setInt(2, ap.getKmInicial());
            ps.setInt(3, ap.getKmFinal());
            ps.setInt(4, ap.getGasolina());  
            ps.setInt(5, ap.getPeaje()); 
            ps.setInt(6, ap.getDietas());  
            ps.setInt(7, ap.getOtros());   
            if(ap.getIncidencia().equals("")){
                ps.setString(8, "Sin incidencia");
            }else{
                ps.setString(8, ap.getIncidencia());   
            }
            ps.setString(9, ap.getEstado());
            ps.setString(10, ap.getT().getDni());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            rs.next();
            Proyecto.setParteId(rs.getInt(1));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());   
        }
    }
    
    public static ArrayList<Parte> seleccionarPartes(Date d)
    {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("Select * from partes where fecha=?");
            ps.setDate(1, d);
            ResultSet rs = ps.executeQuery();
            listado = new ArrayList();
            while(rs.next())
            {
                Proyecto.buscarTrabajador(rs.getString("TRABAJADOR"));
                t = Proyecto.getTrab();
                Parte ap = new Parte(rs.getInt("IDPARTE"),rs.getDate("FECHA"),rs.getInt("KMINICIO"),rs.getInt("KMFINAL"),rs.getInt("GASOLINA"),
                rs.getInt("PEAJE"),rs.getInt("DIETAS"),rs.getInt("OTROS"),rs.getString("INCIDENCIA"),rs.getString("ESTADO"),t);
                listado.add(ap);
            }
            return listado;
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null,"No hay ningun parte abierto ese día");
            return null;
        }
    }
    
    /**
     * Modifica un parte en la base de datos y devuelve true cuando el update es correcto
     * @param ap
     * @return 
     */
    public static boolean actualizarParte(Parte ap)
    {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("UPDATE PARTES SET FECHA=?,KMINICIO=?,KMFINAL=?,GASOLINA=?,PEAJE=?,DIETAS=?,OTROS=?,INCIDENCIA=?,ESTADO=? WHERE IDPARTE=?");
            ps.setDate(1, ap.getFecha());
            ps.setInt(2, ap.getKmInicial());
            ps.setInt(3, ap.getKmFinal());
            ps.setInt(4, ap.getGasolina());
            ps.setInt(5, ap.getPeaje());
            ps.setInt(6, ap.getDietas());
            ps.setInt(7, ap.getOtros());
            ps.setString(8, ap.getIncidencia());
            ps.setString(9, ap.getEstado());
            ps.setInt(10, ap.getIdParte());
            ps.executeUpdate();
            return true;
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
            return false;
        }
        
    }

    /**
     * Selecciona los partes de un dia concreto
     * @param date
     * @return 
     */
    public static ArrayList<Parte> seleccionarPartesTrabajador(Date date) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("Select * from partes where fecha=?");
            ps.setDate(1, date);
            ResultSet rs = ps.executeQuery();
            listado = new ArrayList();
            t = Proyecto.getT();
            while(rs.next())
            {
                if(rs.getString("estado").equalsIgnoreCase("Abierto"))
                {
                    Proyecto.buscarTrabajador(rs.getString("TRABAJADOR"));
                    Parte ap = new Parte(rs.getInt("IDPARTE"),rs.getDate("FECHA"),rs.getInt("KMINICIO"),rs.getInt("KMFINAL"),rs.getInt("GASOLINA"),
                    rs.getInt("PEAJE"),rs.getInt("DIETAS"),rs.getInt("OTROS"),rs.getString("INCIDENCIA"),rs.getString("ESTADO"),t);
                    listado.add(ap);
                }
            }
            return listado;
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null,"No hay ningun parte abierto ese día" + e.getMessage());
            return null;
        }
    }

    /**
     * Selecciona los partes abiertos de un trabajador
     * @return 
     */
    public static Parte seleccionarParteTrabajador() {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("Select * from partes where trabajador = ? and estado = 'Abierto'");
            t = Proyecto.getT();
            ps.setString(1, t.getDni());
            ResultSet rs = ps.executeQuery();
            rs.next();
            Parte ap = new Parte(rs.getInt("IDPARTE"),rs.getDate("FECHA"),rs.getInt("KMINICIO"),rs.getInt("KMFINAL"),rs.getInt("GASOLINA"),
                rs.getInt("PEAJE"),rs.getInt("DIETAS"),rs.getInt("OTROS"),rs.getString("INCIDENCIA"),rs.getString("ESTADO"),t);
            return ap;
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null,"No hay ningun parte abierto ese día" + e.getMessage());
            return null;
        }
    }
    
    /**
     * Devuelve true si el trabajador introducido tiene un parte abierto
     * @param t
     * @return 
     */
    public static boolean seleccionarParteTrabajadorAbierto(Trabajador t) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("Select * from partes where trabajador = ? and estado = 'Abierto'");
            t = Proyecto.getT();
            ps.setString(1, t.getDni());
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return true;
            }else{
                return false;
            }
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null," Error de parte abierto : " +e.getMessage());
            
        }
        return true;
    }

    /**
     * Devuelve los partes no validados en una fecha concreta
     * @param date
     * @return 
     */
    public static ArrayList<Parte> seleccionarPartesNoValidados(Date date) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("Select * from partes where fecha=? and validado = 'No'");
            ps.setDate(1, date);
            ResultSet rs = ps.executeQuery();
            listado = new ArrayList();
            while(rs.next())
            {
                Proyecto.buscarTrabajador(rs.getString("TRABAJADOR"));
                Parte ap = new Parte(rs.getInt("IDPARTE"),rs.getDate("FECHA"),rs.getInt("KMINICIO"),rs.getInt("KMFINAL"),rs.getInt("GASOLINA"),
                rs.getInt("PEAJE"),rs.getInt("DIETAS"),rs.getInt("OTROS"),rs.getString("INCIDENCIA"),rs.getString("ESTADO"), Proyecto.getTrab());
                listado.add(ap);
            }
            return listado;
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null,"No hay ningun parte sin validar ese día" + e.getMessage());
            return null;
        }
    }

    public static void validar(Parte ap){
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("update partes set validado = 'Si' where idparte = ?");
            ps.setInt(1, ap.getIdParte());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Parte validado");
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null,"error" + e.getMessage());
        }
    }
    
    public static void eliminarParte(int idParte){
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("delete from partes where idparte = ?");
            ps.setInt(1, idParte);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Parte eliminado");
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null,"error" + e.getMessage());
        }
    }
    
    /**
     * Selecciona los partes validados de un mes introducido
     * @param pMes
     * @return 
     */
    public static ArrayList<Parte> seleccionarPartesMes(String pMes)
    {
        try {
            int mes = Integer.parseInt(pMes);
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("select * from partes where fecha between '01/" + mes + "/16' and '31/" + mes + "/16' and validado = 'Si'");
            ResultSet rs = ps.executeQuery();
            listado = new ArrayList();
            while(rs.next())
            {
                Proyecto.buscarTrabajador(rs.getString("TRABAJADOR"));
                t = Proyecto.getTrab();
                Parte ap = new Parte(rs.getInt("IDPARTE"),rs.getDate("FECHA"),rs.getInt("KMINICIO"),rs.getInt("KMFINAL"),rs.getInt("GASOLINA"),
                rs.getInt("PEAJE"),rs.getInt("DIETAS"),rs.getInt("OTROS"),rs.getString("INCIDENCIA"),rs.getString("ESTADO"),t);
                listado.add(ap);
            }
            return listado;
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null,"No hay ningun parte ese mes" + e.getMessage());
            return null;
        }
    }
    
}
