/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author 1gprog12
 */
public class ParserBD {
    
    public static int maxID(){
    
        int id = 0;
        String plantilla = "select max(idXML) from InformeXML";
        try{
            PreparedStatement statement = GenericaBD.getCon().prepareStatement(plantilla);
            ResultSet rs = statement.executeQuery();
            if (rs.next()){
                id = rs.getInt(1) + 1;
            }
            return id;
        }
        catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error al seleccionar el ID maximo" + e.getMessage());
            return 0;
        }
    }
    
    /**
     * Inserta el informe en la base de datos XML
     * @param documento 
     */
    public static void InsertarInformesXML(String documento){
    
        String plantilla = "Insert into InformeXML VALUES(?, ?)";
        
        try{
            PreparedStatement ps = GenericaBD.getCon().prepareStatement(plantilla);
            ps.setInt(1, maxID());
            ps.setString(2, documento);
            ps.executeUpdate();
        }
        catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error al insertar el informe " + e.getMessage());
        }
        
        
    
    
    
    
    
    
    }
}
