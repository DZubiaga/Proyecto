package excepciones;

public class HoraInvalida extends Exception{
    
}
